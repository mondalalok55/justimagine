import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from 'src/app/helper/apiService/data.service';
import { CommonfunctionService } from 'src/app/helper/commonfunction/commonfunction.service';
import { ToastService } from 'src/app/helper/toast/toast.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  showLoader: boolean;
  formErrors: any = [];

  constructor(
    // private router: Router, 
    private dataService: DataService,
    private formBuilder: FormBuilder,
    private commonfunc: CommonfunctionService,
    private toast: ToastService,
  ) { }

  ngOnInit() {
    this.formErrors = [];
    this.initializeForm();
  }

  //------------------------------------------------------------------
  //------ register Form initialization
  //------------------------------------------------------------------
  initializeForm() {
    this.registerForm = this.formBuilder.group({
      name: [
        '', 
        Validators.compose(
        [Validators.required, Validators.minLength(2), Validators.maxLength(40), Validators.pattern(/^[a-zA-Z ]*$/)]
      )],
      phone: [
        '', 
        Validators.compose(
        [Validators.required, Validators.minLength(10), Validators.maxLength(13), Validators.pattern(/^[0-9]*$/)]
      )],
      email: [
        null, 
        Validators.compose([Validators.required, Validators.minLength(4), Validators.maxLength(60), Validators.pattern(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i)])
      ],
      password: [
        null, 
        Validators.compose([Validators.required, Validators.minLength(4), Validators.maxLength(20)])
      ],
      confirm_password: [
        '', 
        Validators.compose([Validators.required, Validators.minLength(4), Validators.maxLength(20)])
      ]
    });
  }

  //------------------------------------------------------------------
  //------ checking for both password same
  //------------------------------------------------------------------
  checkPasswords() { 
    let pass = this.registerForm.get('password').value;
    let confirmPass = this.registerForm.get('confirm_password').value;
    // return pass === confirmPass ? null : { notSame: true } 
    //console.log('both passwords : ', pass, confirmPass);
    if(pass === confirmPass){
      return true;
    } else {      
      return false;
    }   
  }

  //------------------------------------------------------------------
  //------ Submit register form
  //------------------------------------------------------------------
  async onSubmit() {
    // console.log('submit clicked....');    
    console.log('submit clicked....',this.registerForm, this.registerForm.hasError('notSame'), this.registerForm.controls, this.registerForm.invalid);    
    this.showLoader = true;

    if (this.registerForm.invalid) {
      this.commonfunc.getFormErrors(this.registerForm).then(async(data: any) => { 
        console.log('form errors : >>>>>>>>>>', data);
        // this.formErrors = data;
        if(data && data.length > 0) {
          let toast = await this.toast.presentToast('Info!', data[0].errorText, "danger"); 
          toast.present();
        }
      }).catch(err=> {
        console.log(err);        
      }); 
      
      this.showLoader = false;
      return;
    } else {
      let checkpassword = this.checkPasswords();
      if (checkpassword == false) {
        let toast = await this.toast.presentToast('Info!', 'Password Not Match', "danger");
        toast.present();

        this.showLoader = false;
      } else {
        let sendData = {
          name: this.registerForm.get('name').value.trim(),
          email: this.registerForm.get('email').value.trim(),
          phone: this.registerForm.get('phone').value.trim(),
          password: this.registerForm.get('password').value.trim()
        }
        console.log('Register sendData: ', sendData);
        this.dataService.custRegister(sendData).subscribe(async response => {
          this.showLoader = false;
          if (response.status == true) {
            let toast = await this.toast.presentToast('Info!', 'Registration successfull!', "success");
            toast.present();

            this.gotoLoginPage();
          } else {
            let toast = await this.toast.presentToast('Info!', response.message, "danger");
            toast.present();
          }
        });
      }
    }
  }

  //------------------------------------------------------------------
  //------ name filter method
  //------------------------------------------------------------------
  onNameType(e){
    let modifiedName = e.target.value.replace(/[\d+`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
    // console.log('name typed...............', modifiedName);        
    e.target.value = modifiedName.toLowerCase().split(' ')
    .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
    .join(' ');
    
    this.registerForm.patchValue({
      name: modifiedName.toLowerCase().split(' ')
      .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
      .join(' ')
    });
  }

  //------------------------------------------------------------------
  //------ Mobile number filter method
  //------------------------------------------------------------------
  onMobileNumberType(e) {
    let num = e.target.value.match(/\d/g);
    if(num == null){
      e.target.value = '';
      this.registerForm.patchValue({
        phone: ''
      });
    }else{
      num = num.join("");
      num = num.toString();
      let trim = num.substring(0, 13);     
      e.target.value = trim;
      // console.log(trim);      
      this.registerForm.patchValue({
        phone: trim
      });
    }      
  }

  //------------------------------------------------------------------
  //------ going to login page
  //------------------------------------------------------------------
  gotoLoginPage(){
    this.commonfunc.goToForward("/main/auth/login");
  }

}
