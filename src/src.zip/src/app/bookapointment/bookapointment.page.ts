import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookapointment',
  templateUrl: './bookapointment.page.html',
  styleUrls: ['./bookapointment.page.scss'],
})
export class BookapointmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
