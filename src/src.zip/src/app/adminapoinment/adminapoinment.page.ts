import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminapoinment',
  templateUrl: './adminapoinment.page.html',
  styleUrls: ['./adminapoinment.page.scss'],
})
export class AdminapoinmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
