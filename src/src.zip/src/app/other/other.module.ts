import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OtherRoutingModule } from './other-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    OtherRoutingModule
  ]
})
export class OtherModule { }
