import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotifyRoutingModule } from './notify-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NotifyRoutingModule
  ]
})
export class NotifyModule { }
